import UIKit

//1. Решить квадратное уравнение.
var a = Double(2)
var b = Double(3)
var c = Double(4)
var delta = Double(b * b) - (4 * a * c)
//delta = (b * b) - (4 * a * c)
print(delta)

//2. Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.
var x1 = Double(2)
var x2 = Double(3)
var S = Double(x1*x2)/2
print(S) //площадь
var P = Double(x1+x2)/2
print(P)//периметр
var x3 = Double(sqrt(x1*x1*x2*x2))
print(x3)//гипотенузу треугольника

//3.*Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через                             5 лет.

var money = Double(50)
var percent = Double(0.9)
var money2 = Double(money*percent)
var money3 = Double(money2*percent)
var money4 = Double(money3*percent)
var money5 = Double(money4*percent)
var moneyears = Double(money+money2+money3+money4+money5)
print(moneyears)//суммf вклада через 5 лет

